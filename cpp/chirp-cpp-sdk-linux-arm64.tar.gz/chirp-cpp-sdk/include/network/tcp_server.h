#pragma once

#include <cstdint>
#include <functional>
#include <memory>
#include <string>

#include <asio.hpp>

#include "network/tcp_session.h"

namespace chirp::network {

class TcpServer {
public:
  using FrameCallback = TcpSession::FrameCallback;
  using CloseCallback = TcpSession::CloseCallback;

  TcpServer(asio::io_context& io, uint16_t port, FrameCallback on_frame, CloseCallback on_close = nullptr,
            const std::string& bind_host = "0.0.0.0");
  virtual ~TcpServer() = default;

  void Start();
  void Stop();

  // The bound port: the requested one, or the ephemeral port the kernel
  // picked when constructed with port 0. Valid immediately after the ctor.
  uint16_t Port() const { return port_; }

  // The bound address (from bind_host). Valid immediately after the ctor.
  const asio::ip::address& BoundAddress() const { return address_; }

private:
  void DoAccept();

  // Declaration order matters: acceptor_ binds io_, so io_ initializes first.
  asio::io_context& io_;
  // Serializes every acceptor_ access: Start()/Stop() run on the caller's
  // thread while DoAccept handlers run on the io thread.
  asio::strand<asio::io_context::executor_type> strand_;
  asio::ip::tcp::acceptor acceptor_;
  uint16_t port_ = 0;
  asio::ip::address address_;

protected:
  // Accept-loop seam: subclasses wrap the accepted socket (e.g. in an
  // ssl::stream) before it becomes a session. Return null to drop the
  // connection.
  virtual std::shared_ptr<Session> MakeSession(asio::ip::tcp::socket socket);

  FrameCallback on_frame_;
  CloseCallback on_close_;
};

} // namespace chirp::network
