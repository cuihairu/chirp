#pragma once

#include <atomic>
#include <cstdint>
#include <functional>
#include <memory>
#include <optional>
#include <string>
#include <vector>
#include <mutex>
#include <thread>
#include <unordered_map>
#include <asio.hpp>

#include "network/redis_protocol.h"

namespace chirp::network {

/// @brief Synchronous Redis client for command operations.
/// Methods are virtual so tests can substitute throwing/misbehaving doubles.
class RedisClient {
public:
  RedisClient(std::string host, uint16_t port);
  virtual ~RedisClient() = default;

  // Generic escape hatch for commands without a dedicated wrapper (e.g.
  // streams). Returns std::nullopt on connection or transport failure.
  virtual std::optional<RedisResp> Command(const std::vector<std::string>& args);

  // Basic commands
  virtual std::optional<std::string> Get(const std::string& key);
  virtual bool SetEx(const std::string& key, const std::string& value, int ttl_seconds);
  // SET without a TTL: durable data (e.g. relationship snapshots) must never
  // silently expire, which any TTL-based variant would eventually do.
  virtual bool Set(const std::string& key, const std::string& value);
  virtual bool Del(const std::string& key);

  // Pub/Sub commands
  virtual bool Publish(const std::string& channel, const std::string& message);

  // PUBLISH with the receiver count Redis reports: how many subscribers got
  // the message; -1 when the command failed (no connection / bad reply).
  virtual int64_t PublishCount(const std::string& channel, const std::string& message);

  // List commands
  bool RPush(const std::string& key, const std::string& value);
  std::vector<std::string> LRange(const std::string& key, int64_t start, int64_t stop);

  // Removes count occurrences of value from the list stored at key (count=1
  // scans head to tail). Returns how many elements were removed, or -1 when
  // the command failed (no connection / bad reply).
  virtual int64_t LRem(const std::string& key, int64_t count, const std::string& value);

  // Sets the list element at index to value. False when the command failed
  // (no connection, index out of range, or any reply other than +OK).
  virtual bool LSet(const std::string& key, int64_t index, const std::string& value);

  // Expiration commands
  bool Expire(const std::string& key, int ttl_seconds);

  // Keys command
  virtual std::vector<std::string> Keys(const std::string& pattern);

private:
  std::string host_;
  uint16_t port_;
};

/// @brief Redis subscriber with multi-channel support.
class RedisSubscriber {
public:
  using MessageCallback = std::function<void(const std::string& channel, const std::string& payload)>;
  using ErrorCallback = std::function<void(const std::string& error)>;
  using ConnectCallback = std::function<void()>;

  RedisSubscriber(std::string host, uint16_t port);
  virtual ~RedisSubscriber();

  RedisSubscriber(const RedisSubscriber&) = delete;
  RedisSubscriber& operator=(const RedisSubscriber&) = delete;

  /// @brief Set the message callback.
  void SetMessageCallback(MessageCallback cb) { msg_cb_ = std::move(cb); }

  /// @brief Set the error callback.
  void SetErrorCallback(ErrorCallback cb) { error_cb_ = std::move(cb); }

  /// @brief Set the connect callback.
  void SetConnectCallback(ConnectCallback cb) { connect_cb_ = std::move(cb); }

  /// @brief Subscribe to a channel.
  virtual bool Subscribe(const std::string& channel);

  /// @brief Unsubscribe from a channel.
  virtual bool Unsubscribe(const std::string& channel);

  /// @brief Start the subscriber.
  virtual void Start();

  /// @brief Stop the subscriber.
  virtual void Stop();

  /// @brief Check whether the subscriber is connected.
  bool IsConnected() const { return connected_; }

private:
  void Run();
  bool SendCommand(const std::string& cmd);
  void ProcessLine(const std::string& line);

  std::string host_;
  uint16_t port_;

  MessageCallback msg_cb_;
  ErrorCallback error_cb_;
  ConnectCallback connect_cb_;

  std::atomic<bool> stop_{false};
  std::atomic<bool> connected_{false};

  std::mutex sock_mu_;
  std::unique_ptr<asio::io_context> io_;
  asio::ip::tcp::socket* socket_ptr_{nullptr};
  std::unique_ptr<asio::ip::tcp::socket> socket_;
  std::thread th_;
};

} // namespace chirp::network
