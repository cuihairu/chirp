import * as Auth from '@chirp/proto/auth';
import * as Chat from '@chirp/proto/chat';
import * as GameServerGateway from '@chirp/proto/game_server_gateway';
import * as Notification from '@chirp/proto/app_notification';
import * as Party from '@chirp/proto/party';
import * as Social from '@chirp/proto/social';
import * as Voice from '@chirp/proto/voice';
import { MsgID } from '@chirp/proto/gateway';

/**
 * A typed request/response pair. On this protocol a response is correlated by
 * Packet.sequence, not by msgId — the server answers with the RESP msgId and
 * echoes the request's sequence. The spec keeps both ids and the codec in one
 * place so call sites never touch raw msgIds.
 */
export interface MessageSpec<Req, Resp> {
  readonly reqMsgId: MsgID;
  readonly respMsgId: MsgID;
  /** Accepts a partial; unset fields fall back to proto defaults via fromPartial. */
  encodeRequest(message: Partial<Req>): Uint8Array;
  decodeResponse(bytes: Uint8Array): Resp;
}

interface ProtoMessage<T> {
  encode(message: T, writer?: unknown): { finish(): Uint8Array };
  decode(input: Uint8Array, length?: number): T;
  fromPartial(partial: Partial<T>): T;
}

function defineSpec<Req, Resp>(
  reqMsgId: MsgID,
  respMsgId: MsgID,
  Req: ProtoMessage<Req>,
  Resp: ProtoMessage<Resp>,
): MessageSpec<Req, Resp> {
  return {
    reqMsgId,
    respMsgId,
    encodeRequest: (message) => Req.encode(Req.fromPartial(message)).finish(),
    decodeResponse: (bytes) => Resp.decode(bytes),
  };
}

// Core pair used by the connection layer itself.
export const LOGIN = defineSpec(
  MsgID.LOGIN_REQ,
  MsgID.LOGIN_RESP,
  Auth.LoginRequest,
  Auth.LoginResponse,
);
export const LOGOUT = defineSpec(
  MsgID.LOGOUT_REQ,
  MsgID.LOGOUT_RESP,
  Auth.LogoutRequest,
  Auth.LogoutResponse,
);

// Chat (direct chat WS entry; the full table grows in the api layer).
export const SEND_MESSAGE = defineSpec(
  MsgID.SEND_MESSAGE_REQ,
  MsgID.SEND_MESSAGE_RESP,
  Chat.SendMessageRequest,
  Chat.SendMessageResponse,
);
export const GET_HISTORY = defineSpec(
  MsgID.GET_HISTORY_REQ,
  MsgID.GET_HISTORY_RESP,
  Chat.GetHistoryRequest,
  Chat.GetHistoryResponse,
);
export const MARK_READ = defineSpec(
  MsgID.MARK_READ_REQ,
  MsgID.MARK_READ_RESP,
  Chat.MarkReadRequest,
  Chat.MarkReadResponse,
);
export const GET_UNREAD_COUNT = defineSpec(
  MsgID.GET_UNREAD_COUNT_REQ,
  MsgID.GET_UNREAD_COUNT_RESP,
  Chat.GetUnreadCountRequest,
  Chat.GetUnreadCountResponse,
);
export const GET_USER_GROUPS = defineSpec(
  MsgID.GET_USER_GROUPS_REQ,
  MsgID.GET_USER_GROUPS_RESP,
  Chat.GetUserGroupsRequest,
  Chat.GetUserGroupsResponse,
);
export const CREATE_GROUP = defineSpec(
  MsgID.CREATE_GROUP_REQ,
  MsgID.CREATE_GROUP_RESP,
  Chat.CreateGroupRequest,
  Chat.CreateGroupResponse,
);
export const INVITE_TO_GROUP = defineSpec(
  MsgID.INVITE_TO_GROUP_REQ,
  MsgID.INVITE_TO_GROUP_RESP,
  Chat.InviteToGroupRequest,
  Chat.InviteToGroupResponse,
);
export const LEAVE_GROUP = defineSpec(
  MsgID.LEAVE_GROUP_REQ,
  MsgID.LEAVE_GROUP_RESP,
  Chat.LeaveGroupRequest,
  Chat.LeaveGroupResponse,
);
export const KICK_MEMBER = defineSpec(
  MsgID.KICK_MEMBER_REQ,
  MsgID.KICK_MEMBER_RESP,
  Chat.KickMemberRequest,
  Chat.KickMemberResponse,
);
export const GET_GROUP_MEMBERS = defineSpec(
  MsgID.GET_GROUP_MEMBERS_REQ,
  MsgID.GET_GROUP_MEMBERS_RESP,
  Chat.GetGroupMembersRequest,
  Chat.GetGroupMembersResponse,
);

// Reactions, edit/delete (typing has no REQ: it is fire-and-forget 2208).
export const ADD_REACTION = defineSpec(
  MsgID.ADD_REACTION_REQ,
  MsgID.ADD_REACTION_RESP,
  Chat.AddReactionRequest,
  Chat.AddReactionResponse,
);
export const REMOVE_REACTION = defineSpec(
  MsgID.REMOVE_REACTION_REQ,
  MsgID.REMOVE_REACTION_RESP,
  Chat.RemoveReactionRequest,
  Chat.RemoveReactionResponse,
);
export const EDIT_MESSAGE = defineSpec(
  MsgID.EDIT_MESSAGE_REQ,
  MsgID.EDIT_MESSAGE_RESP,
  Chat.EditMessageRequest,
  Chat.EditMessageResponse,
);
export const DELETE_MESSAGE = defineSpec(
  MsgID.DELETE_MESSAGE_REQ,
  MsgID.DELETE_MESSAGE_RESP,
  Chat.DeleteMessageRequest,
  Chat.DeleteMessageResponse,
);

// Social plane (WS 8001): the backend serves the full roster surface
// (friends, pending requests, blocked list); friends stay pending-request
// based and presence is a broadcast snapshot.
export const ADD_FRIEND = defineSpec(
  MsgID.ADD_FRIEND_REQ,
  MsgID.ADD_FRIEND_RESP,
  Social.AddFriendRequest,
  Social.AddFriendResponse,
);
export const FRIEND_REQUEST_ACTION = defineSpec(
  MsgID.FRIEND_REQUEST_ACTION_REQ,
  MsgID.FRIEND_REQUEST_ACTION_RESP,
  Social.FriendRequestAction,
  Social.FriendRequestActionResponse,
);
export const REMOVE_FRIEND = defineSpec(
  MsgID.REMOVE_FRIEND_REQ,
  MsgID.REMOVE_FRIEND_RESP,
  Social.RemoveFriendRequest,
  Social.RemoveFriendResponse,
);
export const GET_FRIEND_LIST = defineSpec(
  MsgID.GET_FRIEND_LIST_REQ,
  MsgID.GET_FRIEND_LIST_RESP,
  Social.GetFriendListRequest,
  Social.GetFriendListResponse,
);
export const GET_PENDING_REQUESTS = defineSpec(
  MsgID.GET_PENDING_REQUESTS_REQ,
  MsgID.GET_PENDING_REQUESTS_RESP,
  Social.GetPendingRequestsRequest,
  Social.GetPendingRequestsResponse,
);
export const BLOCK_USER = defineSpec(
  MsgID.BLOCK_USER_REQ,
  MsgID.BLOCK_USER_RESP,
  Social.BlockUserRequest,
  Social.BlockUserResponse,
);
export const UNBLOCK_USER = defineSpec(
  MsgID.UNBLOCK_USER_REQ,
  MsgID.UNBLOCK_USER_RESP,
  Social.UnblockUserRequest,
  Social.UnblockUserResponse,
);
export const GET_BLOCKED_LIST = defineSpec(
  MsgID.GET_BLOCKED_LIST_REQ,
  MsgID.GET_BLOCKED_LIST_RESP,
  Social.GetBlockedListRequest,
  Social.GetBlockedListResponse,
);
export const SET_PRESENCE = defineSpec(
  MsgID.SET_PRESENCE_REQ,
  MsgID.SET_PRESENCE_RESP,
  Social.SetPresenceRequest,
  Social.SetPresenceResponse,
);
export const GET_PRESENCE = defineSpec(
  MsgID.GET_PRESENCE_REQ,
  MsgID.GET_PRESENCE_RESP,
  Social.GetPresenceRequest,
  Social.GetPresenceResponse,
);

// Party plane (WS 7501): cross-game team-up. Invite-accept only, snapshot
// sync (PARTY_STATE_CHANGED carries the full PartyInfo to every member).
export const CREATE_PARTY = defineSpec(
  MsgID.CREATE_PARTY_REQ,
  MsgID.CREATE_PARTY_RESP,
  Party.CreatePartyRequest,
  Party.CreatePartyResponse,
);
export const DISBAND_PARTY = defineSpec(
  MsgID.DISBAND_PARTY_REQ,
  MsgID.DISBAND_PARTY_RESP,
  Party.DisbandPartyRequest,
  Party.DisbandPartyResponse,
);
export const INVITE_TO_PARTY = defineSpec(
  MsgID.INVITE_TO_PARTY_REQ,
  MsgID.INVITE_TO_PARTY_RESP,
  Party.InviteToPartyRequest,
  Party.InviteToPartyResponse,
);
export const ACCEPT_PARTY_INVITE = defineSpec(
  MsgID.ACCEPT_INVITE_REQ,
  MsgID.ACCEPT_INVITE_RESP,
  Party.AcceptInviteRequest,
  Party.AcceptInviteResponse,
);
export const DECLINE_PARTY_INVITE = defineSpec(
  MsgID.DECLINE_INVITE_REQ,
  MsgID.DECLINE_INVITE_RESP,
  Party.DeclineInviteRequest,
  Party.DeclineInviteResponse,
);
export const LEAVE_PARTY = defineSpec(
  MsgID.LEAVE_PARTY_REQ,
  MsgID.LEAVE_PARTY_RESP,
  Party.LeavePartyRequest,
  Party.LeavePartyResponse,
);
export const KICK_PARTY_MEMBER = defineSpec(
  MsgID.KICK_PARTY_MEMBER_REQ,
  MsgID.KICK_PARTY_MEMBER_RESP,
  Party.KickMemberRequest,
  Party.KickMemberResponse,
);
export const TRANSFER_PARTY_LEADER = defineSpec(
  MsgID.TRANSFER_LEADER_REQ,
  MsgID.TRANSFER_LEADER_RESP,
  Party.TransferLeaderRequest,
  Party.TransferLeaderResponse,
);
export const SET_PARTY_READY = defineSpec(
  MsgID.SET_READY_REQ,
  MsgID.SET_READY_RESP,
  Party.SetReadyRequest,
  Party.SetReadyResponse,
);
export const GET_MY_PARTY = defineSpec(
  MsgID.GET_MY_PARTY_REQ,
  MsgID.GET_MY_PARTY_RESP,
  Party.GetMyPartyRequest,
  Party.GetMyPartyResponse,
);

// Device plane (app_gateway WS 5201): registration / listing of the push
// targets for our account. app_gateway authenticates the session and pins
// user_id server-side; 6009 PUSH_NOTIFICATION is deliberately absent — the
// edge refuses it from clients.
export const REGISTER_DEVICE = defineSpec(
  MsgID.REGISTER_DEVICE_REQ,
  MsgID.REGISTER_DEVICE_RESP,
  Notification.RegisterDeviceRequest,
  Notification.RegisterDeviceResponse,
);
export const UNREGISTER_DEVICE = defineSpec(
  MsgID.UNREGISTER_DEVICE_REQ,
  MsgID.UNREGISTER_DEVICE_RESP,
  Notification.UnregisterDeviceRequest,
  Notification.UnregisterDeviceResponse,
);
export const GET_USER_DEVICES = defineSpec(
  MsgID.GET_USER_DEVICES_REQ,
  MsgID.GET_USER_DEVICES_RESP,
  Notification.GetUserDevicesRequest,
  Notification.GetUserDevicesResponse,
);

// Game presence (游戏在线状态, app_gateway self-service like the WP-8 block):
// the per-player switch for the friend-facing "in game X" status and the
// friend-DM relay into the game plane. Binding opts in by default (the
// switch reads true when never set); the server pins player_id.
export const SET_GAME_PRESENCE_ENABLED = defineSpec(
  MsgID.SET_GAME_PRESENCE_ENABLED_REQ,
  MsgID.SET_GAME_PRESENCE_ENABLED_RESP,
  GameServerGateway.SetGamePresenceEnabledRequest,
  GameServerGateway.SetGamePresenceEnabledResponse,
);
export const GET_GAME_PRESENCE = defineSpec(
  MsgID.GET_GAME_PRESENCE_REQ,
  MsgID.GET_GAME_PRESENCE_RESP,
  GameServerGateway.GetGamePresenceRequest,
  GameServerGateway.GetGamePresenceResponse,
);

// Voice plane (WS 9001): room lifecycle and participant-state sync. The
// roster changes ride PARTICIPANT_JOINED/LEFT/STATE_CHANGED notifies; the
// SDP/ICE relay (4007-4009) and SPEAKING_NOTIFY are the media plane and are
// deliberately not exposed to the web protocol-layer client.
export const CREATE_ROOM = defineSpec(
  MsgID.CREATE_ROOM_REQ,
  MsgID.CREATE_ROOM_RESP,
  Voice.CreateRoomRequest,
  Voice.CreateRoomResponse,
);
export const JOIN_ROOM = defineSpec(
  MsgID.JOIN_ROOM_REQ,
  MsgID.JOIN_ROOM_RESP,
  Voice.JoinRoomRequest,
  Voice.JoinRoomResponse,
);
export const LEAVE_ROOM = defineSpec(
  MsgID.LEAVE_ROOM_REQ,
  MsgID.LEAVE_ROOM_RESP,
  Voice.LeaveRoomRequest,
  Voice.LeaveRoomResponse,
);
export const GET_ROOM_INFO = defineSpec(
  MsgID.GET_ROOM_INFO_REQ,
  MsgID.GET_ROOM_INFO_RESP,
  Voice.GetRoomInfoRequest,
  Voice.GetRoomInfoResponse,
);
export const GET_USER_ROOM = defineSpec(
  MsgID.GET_USER_ROOM_REQ,
  MsgID.GET_USER_ROOM_RESP,
  Voice.GetUserRoomRequest,
  Voice.GetUserRoomResponse,
);
export const SET_MUTE = defineSpec(
  MsgID.SET_MUTE_REQ,
  MsgID.SET_MUTE_RESP,
  Voice.SetMuteRequest,
  Voice.SetMuteResponse,
);
export const SET_DEAFEN = defineSpec(
  MsgID.SET_DEAFEN_REQ,
  MsgID.SET_DEAFEN_RESP,
  Voice.SetDeafenRequest,
  Voice.SetDeafenResponse,
);

// 词库下发（2245-2246，docs/design-notes/word_filter.md「词库下发协议」）。
// 2247 UPDATE_NOTIFY 是服务器单向推送，无 REQ/RESP 配对，走 conn.onNotify。
export const WORD_FILTER_FETCH = defineSpec(
  MsgID.WORD_FILTER_FETCH_REQ,
  MsgID.WORD_FILTER_FETCH_RESP,
  Chat.WordFilterFetchRequest,
  Chat.WordFilterFetchResponse,
);

// 消息搜索(SEARCH_MESSAGE_REQ/RESP 2248/2249):keyword 必填,其余可选。
export const SEARCH_MESSAGE = defineSpec(
  MsgID.SEARCH_MESSAGE_REQ,
  MsgID.SEARCH_MESSAGE_RESP,
  Chat.SearchMessageRequest,
  Chat.SearchMessageResponse,
);

// 设置群昵称(SET_MEMBER_ALIAS_REQ/RESP 2122/2123):operator 设置 target
// 在 group 内的显示别名。alias 空串 = 清除。
export const SET_MEMBER_ALIAS = defineSpec(
  MsgID.SET_MEMBER_ALIAS_REQ,
  MsgID.SET_MEMBER_ALIAS_RESP,
  Chat.SetMemberAliasRequest,
  Chat.SetMemberAliasResponse,
);

// 群管理员禁言(SET_GROUP_MUTE_REQ/RESP 2250/2251):MODERATOR+ 禁言/解禁
// target。duration_sec=0 解禁,上限 30 天;2252 全群通知禁言态变更。
export const SET_GROUP_MUTE = defineSpec(
  MsgID.SET_GROUP_MUTE_REQ,
  MsgID.SET_GROUP_MUTE_RESP,
  Chat.SetGroupMuteRequest,
  Chat.SetGroupMuteResponse,
);
